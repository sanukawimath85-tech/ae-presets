C:\Program Files\Adobe\Adobe After Effects\Support Files\Plug-ins

                                       <-------------------------------------->
                                                      Credits go to
                                              https://discord.gg/HpnQhVueGH
                                                      Join for more
                                          <-------------------------------------->


